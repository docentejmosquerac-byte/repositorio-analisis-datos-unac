"""
Análisis bivariable (correlación) del inventario militar scrapeado.

Uso:
    python analisis_bivariable.py [carpeta_raiz]

Si no se indica carpeta, usa la carpeta donde está este archivo (la raíz
del proyecto 'Scraping', que contiene Brazil/, China/, etc.).

Nota sobre los datos: en los CSV las cabeceras (variante, activos,
almacenados, ordenados) quedaron desalineadas respecto al contenido, por lo
que se reconstruyen las variables numéricas a partir de 'datos_fila_raw',
que sí conserva el orden original de la tabla:
    Army / Air Force : nombre | activos | variación (+/-) o almacenados  [| extra]
    Navy             : nombre  estado  año   (una fila = un buque, o "(N ships)")
"""
import re
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

RAIZ = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent
SALIDA = RAIZ / "resultados_bivariable"
SALIDA.mkdir(exist_ok=True)

PAISES = {
    "Brazil": "Brasil", "China": "China", "Colombia": "Colombia",
    "France": "Francia", "Germany": "Alemania", "India": "India",
    "Japon": "Japón", "Rusia": "Rusia", "South_Korea": "Corea del Sur",
    "United_States": "EE. UU.",
}


# --------------------------------------------------------------------------
# 1. Carga y reconstrucción de variables
# --------------------------------------------------------------------------
def a_numero(txt):
    """'2,640' -> 2640.0 ; '—' -> NaN"""
    txt = str(txt).strip().replace(",", "")
    return float(txt) if re.fullmatch(r"\d+", txt) else np.nan


def a_cambio(txt):
    """'+94' -> 94.0 ; '-3' -> -3.0 ; '—' -> NaN"""
    txt = str(txt).strip().replace(",", "")
    return float(txt) if re.fullmatch(r"[+-]\d+", txt) else np.nan


def rama_de(ruta):
    nombre = ruta.name.lower()
    if "navy" in nombre:
        return "Navy"
    return "Air Force" if "air_force" in nombre else "Army"


def cargar():
    tierra_aire, navales = [], []
    for ruta in sorted(RAIZ.glob("*/*_limpio.csv")):
        pais = PAISES.get(ruta.parent.name, ruta.parent.name)
        rama = rama_de(ruta)
        df = pd.read_csv(ruta, encoding="utf-8-sig")

        for _, f in df.iterrows():
            raw = str(f["datos_fila_raw"])

            if rama == "Navy":
                m = re.search(r"\((\d+)\s+(?:ships|boats)\)", raw)
                unidades = int(m.group(1)) if m else 1
                est = re.search(r"\b(Active|Reserve|Planned|Fitting Out)\b", raw)
                anio = re.search(r"(\d{4})\s*$", raw)
                navales.append({
                    "pais": pais, "categoria": f["categoria"],
                    "estado": est.group(1) if est else "Otro",
                    "unidades": unidades,
                    "anio": int(anio.group(1)) if anio else np.nan,
                })
                continue

            partes = [p.strip() for p in raw.split(" | ")]
            if len(partes) >= 3:
                nombre, activos, resto = " | ".join(partes[:-2]), partes[-2], partes[-1]
            else:  # filas solo "pedidas": no tienen cifra de activos
                nombre, activos, resto = partes[0], "—", ""
            toks = resto.split()
            anio = re.search(r"(\d{4})\s*$", nombre) if rama == "Air Force" else None
            tierra_aire.append({
                "pais": pais, "rama": rama, "categoria": f["categoria"],
                "equipo": nombre,
                "activos": a_numero(activos),
                "variacion": a_cambio(toks[0]) if toks else np.nan,
                "anio": int(anio.group(1)) if anio else np.nan,
            })
    return pd.DataFrame(tierra_aire), pd.DataFrame(navales)


# --------------------------------------------------------------------------
# 2. Utilidades de correlación
# --------------------------------------------------------------------------
def correlacion(x, y, nombre_x, nombre_y, nivel, log_x=False, log_y=False):
    d = pd.DataFrame({"x": x, "y": y}).dropna()
    if log_x:
        d = d[d.x > 0]
        d["x"] = np.log10(d.x)
    if log_y:
        d = d[d.y > 0]
        d["y"] = np.log10(d.y)
    n = len(d)
    if n < 3:
        return None
    r, p_r = stats.pearsonr(d.x, d.y)
    rho, p_rho = stats.spearmanr(d.x, d.y)
    return {
        "nivel": nivel, "variable_x": nombre_x, "variable_y": nombre_y, "n": n,
        "log10": "x" if log_x and not log_y else "y" if log_y and not log_x
        else "x e y" if log_x and log_y else "no",
        "pearson_r": round(r, 3), "pearson_p": round(p_r, 4),
        "spearman_rho": round(rho, 3), "spearman_p": round(p_rho, 4),
    }


def interpreta(r):
    a = abs(r)
    fuerza = ("muy débil" if a < .2 else "débil" if a < .4 else
              "moderada" if a < .6 else "fuerte" if a < .8 else "muy fuerte")
    return f"{fuerza} {'positiva' if r > 0 else 'negativa'}"


def dispersion(d, x, y, titulo, xlabel, ylabel, archivo, log_x=False, log_y=False,
               etiquetas=None):
    d = d[[x, y] + ([etiquetas] if etiquetas else [])].dropna()
    if log_x:
        d = d[d[x] > 0]
    if log_y:
        d = d[d[y] > 0]
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.scatter(d[x], d[y], alpha=.65, edgecolor="k", linewidth=.4, s=45)
    xs = np.log10(d[x]) if log_x else d[x]
    ys = np.log10(d[y]) if log_y else d[y]
    if len(d) >= 3 and xs.nunique() > 1:
        b, a0 = np.polyfit(xs, ys, 1)
        xx = np.linspace(xs.min(), xs.max(), 100)
        yy = a0 + b * xx
        ax.plot(10 ** xx if log_x else xx, 10 ** yy if log_y else yy,
                color="crimson", lw=2, label="Recta de regresión")
        r, _ = stats.pearsonr(xs, ys)
        rho, _ = stats.spearmanr(xs, ys)
        ax.set_title(f"{titulo}\nPearson r = {r:.2f} | Spearman ρ = {rho:.2f} | n = {len(d)}")
        ax.legend()
    if etiquetas:
        for _, f in d.iterrows():
            ax.annotate(f[etiquetas], (f[x], f[y]), fontsize=8,
                        xytext=(4, 4), textcoords="offset points")
    if log_x:
        ax.set_xscale("log")
    if log_y:
        ax.set_yscale("log")
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.grid(alpha=.3)
    fig.tight_layout()
    fig.savefig(SALIDA / archivo, dpi=150)
    plt.close(fig)


# --------------------------------------------------------------------------
# 3. Análisis
# --------------------------------------------------------------------------
def main():
    ta, nav = cargar()
    ta.to_csv(SALIDA / "equipos_tierra_aire.csv", index=False, encoding="utf-8-sig")
    nav.to_csv(SALIDA / "buques.csv", index=False, encoding="utf-8-sig")
    resultados = []

    # ---- 3.1 Nivel país (n = 10): tamaño de cada rama ---------------------
    activos_nav = nav[nav.estado == "Active"]
    pais = pd.DataFrame({
        "ejercito_unidades": ta[ta.rama == "Army"].groupby("pais").activos.sum(),
        "aviacion_unidades": ta[ta.rama == "Air Force"].groupby("pais").activos.sum(),
        "armada_buques": activos_nav.groupby("pais").unidades.sum(),
        "anio_medio_aviacion": ta[ta.rama == "Air Force"].groupby("pais").anio.mean(),
        "anio_medio_armada": activos_nav.groupby("pais").anio.mean(),
    })
    pais.round(1).to_csv(SALIDA / "resumen_por_pais.csv", encoding="utf-8-sig")

    pares_pais = [
        ("ejercito_unidades", "aviacion_unidades", "Ejército (unidades)", "Aviación (unidades)"),
        ("ejercito_unidades", "armada_buques", "Ejército (unidades)", "Armada (buques)"),
        ("aviacion_unidades", "armada_buques", "Aviación (unidades)", "Armada (buques)"),
        ("anio_medio_aviacion", "anio_medio_armada", "Año medio aviación", "Año medio armada"),
    ]
    for cx, cy, lx, ly in pares_pais:
        log = "anio" not in cx
        res = correlacion(pais[cx], pais[cy], lx, ly, "País", log, log)
        if res:
            resultados.append(res)
        d = pais.reset_index().rename(columns={"index": "pais"})
        dispersion(d, cx, cy, f"{lx} vs {ly}", lx + (" [log]" if log else ""),
                   ly + (" [log]" if log else ""), f"pais_{cx}_vs_{cy}.png",
                   log_x=log, log_y=log, etiquetas="pais")

    # Heatmap de correlación de Spearman entre las variables a nivel país
    cm = pais.corr(method="spearman")
    fig, ax = plt.subplots(figsize=(7, 6))
    im = ax.imshow(cm, cmap="RdBu_r", vmin=-1, vmax=1)
    ax.set_xticks(range(len(cm)), cm.columns, rotation=45, ha="right")
    ax.set_yticks(range(len(cm)), cm.columns)
    for i in range(len(cm)):
        for j in range(len(cm)):
            ax.text(j, i, f"{cm.iloc[i, j]:.2f}", ha="center", va="center", fontsize=9)
    fig.colorbar(im, label="Spearman ρ")
    ax.set_title("Matriz de correlación (Spearman) a nivel país, n = 10")
    fig.tight_layout()
    fig.savefig(SALIDA / "heatmap_pais.png", dpi=150)
    plt.close(fig)
    cm.round(3).to_csv(SALIDA / "matriz_correlacion_pais.csv", encoding="utf-8-sig")

    # ---- 3.2 Nivel equipo, aviación --------------------------------------
    aire = ta[ta.rama == "Air Force"]
    for cx, cy, lx, ly, lgx, lgy in [
        ("anio", "activos", "Año de introducción", "Unidades activas", False, True),
        ("anio", "variacion", "Año de introducción", "Variación reportada (+/-)", False, False),
        ("activos", "variacion", "Unidades activas", "Variación reportada (+/-)", True, False),
    ]:
        res = correlacion(aire[cx], aire[cy], lx, ly, "Equipo (aviación)", lgx, lgy)
        if res:
            resultados.append(res)
        dispersion(aire, cx, cy, f"Aviación: {lx} vs {ly}",
                   lx + (" [log]" if lgx else ""), ly + (" [log]" if lgy else ""),
                   f"aviacion_{cx}_vs_{cy}.png", log_x=lgx, log_y=lgy)

    # ---- 3.3 Nivel equipo, ejército --------------------------------------
    ej = ta[ta.rama == "Army"]
    res = correlacion(ej.activos, ej.variacion, "Unidades activas", "Variación reportada (+/-)",
                      "Equipo (ejército)", True, False)
    if res:
        resultados.append(res)

    # ---- 3.4 Nivel país-categoría, armada: nº de buques vs antigüedad ----
    cat = activos_nav.groupby(["pais", "categoria"]).agg(
        buques=("unidades", "sum"), anio_medio=("anio", "mean")).reset_index()
    cat = cat[cat.buques >= 3]
    res = correlacion(cat.buques, cat.anio_medio, "Buques por categoría", "Año medio de entrada en servicio",
                      "País-categoría (armada)", True, False)
    if res:
        resultados.append(res)
    dispersion(cat, "buques", "anio_medio", "Armada: buques por categoría vs año medio",
               "Buques por categoría [log]", "Año medio de entrada en servicio",
               "armada_buques_vs_anio.png", log_x=True)

    out = pd.DataFrame(resultados)
    out["interpretacion_pearson"] = out.pearson_r.apply(interpreta)
    out["significativa_5pct"] = np.where(out.pearson_p < .05, "sí", "no")
    out.to_csv(SALIDA / "resultados_correlaciones.csv", index=False, encoding="utf-8-sig")
    pd.set_option("display.width", 250, "display.max_columns", 20)
    print(out.to_string(index=False))
    print("\nResumen por país:\n", pais.round(1))


if __name__ == "__main__":
    main()
