import csv
from pathlib import Path

UMBRAL_DATOS_FALTANTES = 0.30
VALORES_FALTANTES = {"", "__", "--", "null", "none", "nan", "nulo", " "}


def es_valor_faltante(valor):
    return valor is None or valor.strip().casefold() in VALORES_FALTANTES


def limpiar_csv(ruta_csv):
    ruta_csv = Path(ruta_csv)

    with ruta_csv.open("r", newline="", encoding="utf-8-sig") as archivo:
        lector = csv.reader(archivo)
        cabeceras = next(lector, None)

        if cabeceras is None:
            print(f"\n{ruta_csv}: 0 registros; archivo vacío, no se generó copia.")
            return 0, []

        faltantes_por_columna = [0] * len(cabeceras)
        total_registros = 0

        for numero_fila, fila in enumerate(lector, start=2):
            if not fila:
                continue
            if len(fila) > len(cabeceras):
                raise ValueError(
                    f"{ruta_csv}, fila {numero_fila}: hay más valores que columnas."
                )

            total_registros += 1
            for indice in range(len(cabeceras)):
                valor = fila[indice] if indice < len(fila) else None
                if es_valor_faltante(valor):
                    faltantes_por_columna[indice] += 1

    indices_eliminados = [
        indice
        for indice, cantidad_faltante in enumerate(faltantes_por_columna)
        if total_registros
        and cantidad_faltante / total_registros >= UMBRAL_DATOS_FALTANTES
    ]
    indices_conservar = [
        indice
        for indice in range(len(cabeceras))
        if indice not in indices_eliminados
    ]
    columnas_eliminadas = [cabeceras[indice] for indice in indices_eliminados]
    ruta_limpia = ruta_csv.with_name(f"{ruta_csv.stem}_limpio{ruta_csv.suffix}")

    with ruta_csv.open("r", newline="", encoding="utf-8-sig") as entrada:
        lector = csv.reader(entrada)
        next(lector, None)
        with ruta_limpia.open("w", newline="", encoding="utf-8-sig") as salida:
            escritor = csv.writer(salida)
            escritor.writerow([cabeceras[indice] for indice in indices_conservar])

            for numero_fila, fila in enumerate(lector, start=2):
                if not fila:
                    continue
                if len(fila) > len(cabeceras):
                    raise ValueError(
                        f"{ruta_csv}, fila {numero_fila}: "
                        "hay más valores que columnas."
                    )
                escritor.writerow(
                    [fila[indice] if indice < len(fila) else "" for indice in indices_conservar]
                )

    return total_registros, columnas_eliminadas


def limpiar_archivos_csv(carpeta_raiz):
    carpeta_raiz = Path(carpeta_raiz)
    archivos_csv = sorted(
        ruta
        for ruta in carpeta_raiz.rglob("*")
        if ruta.is_file()
        and ruta.suffix.casefold() == ".csv"
        and not ruta.stem.casefold().endswith("_limpio")
    )

    if not archivos_csv:
        print(f"No se encontraron archivos CSV en {carpeta_raiz}.")
        return

    for ruta_csv in archivos_csv:
        total_registros, columnas_eliminadas = limpiar_csv(ruta_csv)
        print(f"\nArchivo: {ruta_csv.relative_to(carpeta_raiz)}")
        print(f"Registros: {total_registros}")
        if columnas_eliminadas:
            print("Columnas eliminadas: " + ", ".join(columnas_eliminadas))
        else:
            print("Columnas eliminadas: ninguna")
        if ruta_csv.exists() and total_registros >= 0:
            print(
                f"Copia limpia: "
                f"{ruta_csv.with_name(f'{ruta_csv.stem}_limpio{ruta_csv.suffix}').name}"
            )


if __name__ == "__main__":
    limpiar_archivos_csv(Path(__file__).resolve().parent)