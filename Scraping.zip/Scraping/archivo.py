import csv
import json
import os
import time
from selenium.webdriver.common.by import By
import undetected_chromedriver as uc


class ScraperInventarioMilitar:

    def __init__(self):
        print("Iniciando Scraper de Inventario Militar...")
        options = uc.ChromeOptions()
        options.add_argument("--start-maximized")
        self.driver = uc.Chrome(options=options, version_main=151)

    def cerrar(self):
        try:
            self.driver.quit()
        except Exception:
            pass
        print("\nScraper cerrado de forma limpia.")

    def extraer_inventario(self, url_destino, nombre_base):
        print(f"\nCargando la página: {url_destino}")
        self.driver.get(url_destino)

        print("\n" + "=" * 65)
        print("1. Revisa Chrome.")
        print("2. Resuelve Cloudflare si aparece.")
        print(
            "3. Asegúrate de ver la tabla 'FULL INVENTORY IN 2026' en pantalla."
        )
        input("===> PRESIONA 'ENTER' AQUÍ PARA CAPTURAR EL INVENTARIO <===")
        print("=" * 65 + "\n")

        inventario = []
        categoria_actual = "GENERAL"

        filas = self.driver.find_elements(By.XPATH, "//table//tr")

        for fila in filas:
            texto = fila.text.strip()
            if not texto:
                continue

            celdas = fila.find_elements(By.TAG_NAME, "td")
            if (
                len(celdas) == 1
                or "MAIN BATTLE TANK" in texto
                or "INFANTRY" in texto
                or "ARMORED" in texto
            ):
                categoria_actual = texto.split("\n")[0]
                continue

            if len(celdas) >= 4 or len(texto.split("\n")) >= 2:
                partes = texto.split("\n")
                equipo = partes[0] if len(partes) > 0 else "N/A"

                if equipo in [
                    "EQUIPMENT",
                    "VARIANT",
                    "ACTIVE",
                    "STORED",
                    "ORDERED",
                ]:
                    continue

                item = {
                    "categoria": categoria_actual,
                    "equipo": equipo,
                    "variante": partes[1]
                    if len(partes) > 1 and partes[1] == "—"
                    else (partes[1] if len(partes) > 1 else "—"),
                    "activos": "N/A",
                    "almacenados": "—",
                    "ordenados": "—",
                    "datos_fila_raw": " | ".join(partes),
                }

                numeros = [
                    p for p in partes if any(char.isdigit() for char in p)
                ]
                if len(numeros) >= 1:
                    item["activos"] = numeros[0]
                if len(numeros) >= 2:
                    item["almacenados"] = numeros[1]
                if len(numeros) >= 3:
                    item["ordenados"] = numeros[2]

                inventario.append(item)

        print(
            f"-> ¡Éxito! Se capturaron {len(inventario)} equipos del inventario.\n"
        )

        # Definir nombres finales de archivo
        archivo_json = f"{nombre_base}.json"
        archivo_csv = f"{nombre_base}.csv"

        # 1. Guardar en JSON (Si ya existe el archivo, fusiona los datos sin borrar los anteriores)
        datos_previos = []
        if os.path.exists(archivo_json):
            try:
                with open(archivo_json, "r", encoding="utf-8") as f_old:
                    datos_previos = json.load(f_old)
            except Exception:
                datos_previos = []

        datos_totales = datos_previos + inventario

        with open(archivo_json, "w", encoding="utf-8") as f_json:
            json.dump(datos_totales, f_json, ensure_ascii=False, indent=4)

        # 2. Guardar en CSV (Añade registros sin sobrescribir las cabeceras)
        if inventario:
            existe_csv = os.path.exists(archivo_csv)
            with open(
                archivo_csv,
                "a",
                newline="",
                encoding="utf-8-sig",
            ) as f_csv:
                writer = csv.DictWriter(f_csv, fieldnames=inventario[0].keys())
                if not existe_csv:
                    writer.writeheader()
                writer.writerows(inventario)

        print(f"¡Archivos guardados con éxito!")
        print(f"  - JSON: '{archivo_json}'")
        print(f"  - CSV:  '{archivo_csv}'")


# --- EJECUCIÓN ---
if __name__ == "__main__":
    bot = None
    try:
        bot = ScraperInventarioMilitar()

        url = input("1. Pega la URL del inventario a extraer: ").strip()

        if url:
            # Solicitar el nombre personalizado para guardar
            nombre_archivo = input(
                "2. ¿Qué nombre quieres darle a los archivos? (ej: ejercito_usa, aviacion_china): "
            ).strip()

            # Si el usuario no escribe nada, le asigna un nombre por defecto
            if not nombre_archivo:
                nombre_archivo = "inventario_militar"

            # Limpiar caracteres no válidos para nombres de archivo
            nombre_archivo = (
                nombre_archivo.replace(" ", "_")
                .replace("/", "_")
                .replace("\\", "_")
            )

            bot.extraer_inventario(url, nombre_archivo)

    finally:
        if bot:
            bot.cerrar()